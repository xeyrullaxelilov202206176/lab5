
// let result = document.getElementById('result');

// function appendToDisplay(value) {
//     result.value += value;
// }

// function calculate() {
//     try {
//         result.value = eval(result.value);
//     } catch (error) {
//         result.value = 'Xəta baş verdi';
//     }
// }

// function operate(operator) {
//     result.value += operator;
// }



let displayValue = '';

function appendValue(value) {
  displayValue += value;
  updateDisplay();
}

function calculate() {
  try {
    const result = eval(displayValue);
    displayValue = result.toString();
    updateDisplay();
  } catch (error) {
    displayValue = 'Xəta';
    updateDisplay();
  }
}

function clearDisplay() {
  displayValue = '';
  updateDisplay();
}

function updateDisplay() {
  document.getElementById('display').value = displayValue;
}

